from wtforms.validators import DataRequired
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, EmailField, IntegerField, DateTimeField
from sqlalchemy_serializer import SerializerMixin


class JobForm(FlaskForm):
    team_leader = IntegerField('Тим лид', validators=[DataRequired()])
    job = StringField('Описание работы', validators=[DataRequired()])
    work_size = IntegerField('Размер работы', validators=[DataRequired()])
    collaborators = StringField('Участники', validators=[DataRequired()])
    is_finished = BooleanField('Законена да/нет')
    submit = SubmitField('Добавить')